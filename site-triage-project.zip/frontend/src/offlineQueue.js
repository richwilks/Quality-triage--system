import { get, set } from "idb-keyval";

const QUEUE_KEY = "site-triage-pending-queue";

/**
 * A queued item is stored with the photo as a base64 string (not a Blob)
 * because IndexedDB via idb-keyval handles plain serializable data most
 * reliably across browsers. We convert back to a Blob at sync time.
 */

export async function getQueue() {
  const queue = await get(QUEUE_KEY);
  return queue || [];
}

export async function addToQueue(item) {
  const queue = await getQueue();
  const entry = { ...item, id: crypto.randomUUID(), queuedAt: new Date().toISOString() };
  queue.push(entry);
  await set(QUEUE_KEY, queue);
  return entry;
}

export async function removeFromQueue(id) {
  const queue = await getQueue();
  const next = queue.filter((item) => item.id !== id);
  await set(QUEUE_KEY, next);
  return next;
}

export function blobToBase64(blob) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result.split(",")[1]);
    reader.onerror = () => reject(new Error("Could not read photo"));
    reader.readAsDataURL(blob);
  });
}

export function base64ToBlob(base64, mimeType) {
  const byteChars = atob(base64);
  const byteNumbers = new Array(byteChars.length);
  for (let i = 0; i < byteChars.length; i++) {
    byteNumbers[i] = byteChars.charCodeAt(i);
  }
  return new Blob([new Uint8Array(byteNumbers)], { type: mimeType });
}
