import { useState, useEffect, useCallback, useRef } from "react";
import { Camera, Upload, RotateCcw, Check, Wifi, WifiOff, RefreshCw, FileDown, LogOut } from "lucide-react";
import * as api from "./api.js";
import { getQueue, addToQueue, removeFromQueue, blobToBase64, base64ToBlob } from "./offlineQueue.js";

const CATEGORY_STYLE = {
  snag: { label: "SNAG", color: "#3E5C6E" },
  defect: { label: "DEFECT", color: "#B8791F" },
  ncr: { label: "NCR", color: "#B23A2A" },
  review: { label: "NEEDS REVIEW", color: "#5B5548" },
};

function useOnlineStatus() {
  const [online, setOnline] = useState(navigator.onLine);
  useEffect(() => {
    const goOnline = () => setOnline(true);
    const goOffline = () => setOnline(false);
    window.addEventListener("online", goOnline);
    window.addEventListener("offline", goOffline);
    return () => {
      window.removeEventListener("online", goOnline);
      window.removeEventListener("offline", goOffline);
    };
  }, []);
  return online;
}

function LoginScreen({ onLogin }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState(null);
  const [busy, setBusy] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const { token, user } = await api.login(email, password);
      onLogin(token, user);
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: "#ECEEE9" }}>
      <form onSubmit={submit} className="w-full max-w-sm p-6 rounded-md" style={{ backgroundColor: "#F8F7F2" }}>
        <h1 className="text-xl font-bold mb-1" style={{ fontFamily: "'Oswald', sans-serif", color: "#202B26" }}>
          SITE TRIAGE
        </h1>
        <p className="text-xs mb-4" style={{ color: "#5B5548" }}>Sign in to continue</p>
        <input
          type="email"
          placeholder="Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="w-full px-3 py-2 mb-2 rounded-sm border text-sm"
          style={{ borderColor: "#D8D6CB" }}
          required
        />
        <input
          type="password"
          placeholder="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          className="w-full px-3 py-2 mb-3 rounded-sm border text-sm"
          style={{ borderColor: "#D8D6CB" }}
          required
        />
        {error && <p className="text-xs mb-2" style={{ color: "#B23A2A" }}>{error}</p>}
        <button
          type="submit"
          disabled={busy}
          className="w-full py-2.5 rounded-sm text-sm font-semibold"
          style={{ backgroundColor: "#202B26", color: "#F8F7F2" }}
        >
          {busy ? "Signing in…" : "Sign in"}
        </button>
      </form>
    </div>
  );
}

export default function App() {
  const [token, setToken] = useState(() => localStorage.getItem("st_token"));
  const [user, setUser] = useState(() => {
    const raw = localStorage.getItem("st_user");
    return raw ? JSON.parse(raw) : null;
  });
  const online = useOnlineStatus();

  const [sites, setSites] = useState([]);
  const [siteId, setSiteId] = useState(() => localStorage.getItem("st_site") || "");
  const [newSiteName, setNewSiteName] = useState("");

  const [serverLog, setServerLog] = useState([]);
  const [queue, setQueue] = useState([]);
  const [syncing, setSyncing] = useState(false);

  const [photo, setPhoto] = useState(null);
  const [photoBlob, setPhotoBlob] = useState(null);
  const [context, setContext] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState(null);
  const fileInputRef = useRef(null);

  const handleLogin = (tok, u) => {
    localStorage.setItem("st_token", tok);
    localStorage.setItem("st_user", JSON.stringify(u));
    setToken(tok);
    setUser(u);
  };

  const handleLogout = () => {
    localStorage.removeItem("st_token");
    localStorage.removeItem("st_user");
    setToken(null);
    setUser(null);
  };

  const refreshSites = useCallback(async () => {
    if (!token || !online) return;
    try {
      const { sites } = await api.getSites(token);
      setSites(sites);
      if (!siteId && sites.length > 0) setSiteId(sites[0].id);
    } catch (err) {
      // silently ignore — likely offline or token expired
    }
  }, [token, online, siteId]);

  const refreshLog = useCallback(async () => {
    if (!token || !online || !siteId) return;
    try {
      const { defects } = await api.getDefects(token, siteId);
      setServerLog(defects);
    } catch (err) {
      // ignore
    }
  }, [token, online, siteId]);

  const refreshQueue = useCallback(async () => {
    setQueue(await getQueue());
  }, []);

  useEffect(() => {
    refreshSites();
  }, [refreshSites]);

  useEffect(() => {
    refreshLog();
    refreshQueue();
  }, [refreshLog, refreshQueue]);

  useEffect(() => {
    if (siteId) localStorage.setItem("st_site", siteId);
  }, [siteId]);

  // --- Sync queued items whenever we come back online ---
  const syncQueue = useCallback(async () => {
    if (!online || !token) return;
    const items = await getQueue();
    if (items.length === 0) return;

    setSyncing(true);
    for (const item of items) {
      try {
        const blob = base64ToBlob(item.photoBase64, item.mimeType);
        await api.uploadDefect(token, { siteId: item.siteId, context: item.context, photoBlob: blob });
        await removeFromQueue(item.id);
      } catch (err) {
        // stop on first failure — likely connection dropped again, retry next time
        break;
      }
    }
    setSyncing(false);
    await refreshQueue();
    await refreshLog();
  }, [online, token, refreshQueue, refreshLog]);

  useEffect(() => {
    if (online) syncQueue();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [online]);

  const handleFile = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setError(null);
    setPhoto(URL.createObjectURL(file));
    setPhotoBlob(file);
  };

  const resetCapture = () => {
    setPhoto(null);
    setPhotoBlob(null);
    setContext("");
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  const submitPhoto = async () => {
    if (!photoBlob || !siteId) return;
    setSubmitting(true);
    setError(null);

    if (online) {
      try {
        await api.uploadDefect(token, { siteId, context: context.trim(), photoBlob });
        await refreshLog();
        resetCapture();
      } catch (err) {
        setError(`Upload failed: ${err.message}. It's been queued instead.`);
        await queueCurrentPhoto();
      }
    } else {
      await queueCurrentPhoto();
    }
    setSubmitting(false);
  };

  const queueCurrentPhoto = async () => {
    const base64 = await blobToBase64(photoBlob);
    await addToQueue({
      siteId,
      context: context.trim(),
      photoBase64: base64,
      mimeType: photoBlob.type || "image/jpeg",
    });
    await refreshQueue();
    resetCapture();
  };

  const createSite = async () => {
    if (!newSiteName.trim()) return;
    try {
      const { site } = await api.createSite(token, { name: newSiteName.trim() });
      setNewSiteName("");
      await refreshSites();
      setSiteId(site.id);
    } catch (err) {
      setError(err.message);
    }
  };

  const downloadReport = async () => {
    if (!siteId) return;
    try {
      const url = await api.downloadSiteReport(token, siteId);
      window.open(url, "_blank");
    } catch (err) {
      setError("Could not download report — you need to be online for this.");
    }
  };

  if (!token || !user) {
    return <LoginScreen onLogin={handleLogin} />;
  }

  return (
    <div className="min-h-screen" style={{ backgroundColor: "#ECEEE9" }}>
      <header className="px-5 py-4 border-b sticky top-0 z-10" style={{ backgroundColor: "#202B26" }}>
        <div className="flex items-center justify-between">
          <h1 className="text-lg" style={{ fontFamily: "'Oswald', sans-serif", color: "#F8F7F2", fontWeight: 700 }}>
            SITE TRIAGE
          </h1>
          <div className="flex items-center gap-3">
            {online ? <Wifi size={16} color="#8FD19E" /> : <WifiOff size={16} color="#E8A33D" />}
            <button onClick={handleLogout}><LogOut size={16} color="#F8F7F2" /></button>
          </div>
        </div>
        <p className="text-xs mt-0.5" style={{ color: "#9CA89E" }}>
          {user.name} · {online ? "Online" : "Offline — photos will queue locally"}
        </p>
      </header>

      <main className="max-w-lg mx-auto px-4 py-5 space-y-5">
        {/* Site selector */}
        <div className="rounded-md p-3" style={{ backgroundColor: "#F8F7F2" }}>
          <label className="text-xs uppercase tracking-wide" style={{ color: "#5B5548" }}>Site</label>
          <select
            value={siteId}
            onChange={(e) => setSiteId(e.target.value)}
            className="w-full mt-1 px-2 py-2 rounded-sm border text-sm"
            style={{ borderColor: "#D8D6CB" }}
          >
            <option value="">Select a site…</option>
            {sites.map((s) => (
              <option key={s.id} value={s.id}>{s.name} ({s.open_defect_count} open)</option>
            ))}
          </select>
          {online && (
            <div className="flex gap-2 mt-2">
              <input
                type="text"
                placeholder="New site name"
                value={newSiteName}
                onChange={(e) => setNewSiteName(e.target.value)}
                className="flex-1 px-2 py-1.5 rounded-sm border text-sm"
                style={{ borderColor: "#D8D6CB" }}
              />
              <button onClick={createSite} className="px-3 py-1.5 rounded-sm text-sm font-medium" style={{ backgroundColor: "#202B26", color: "#F8F7F2" }}>
                Add
              </button>
            </div>
          )}
        </div>

        {/* Sync status */}
        {queue.length > 0 && (
          <div className="rounded-md p-3 flex items-center justify-between" style={{ backgroundColor: "#FBF1E0" }}>
            <span className="text-sm" style={{ color: "#5B5548" }}>
              {queue.length} item{queue.length > 1 ? "s" : ""} queued, awaiting connection
            </span>
            {online && (
              <button onClick={syncQueue} disabled={syncing} className="flex items-center gap-1 text-sm font-medium" style={{ color: "#B8791F" }}>
                <RefreshCw size={14} className={syncing ? "animate-spin" : ""} /> {syncing ? "Syncing…" : "Sync now"}
              </button>
            )}
          </div>
        )}

        {/* Capture */}
        {siteId && (
          <div className="rounded-md border-2 border-dashed p-6 text-center" style={{ borderColor: "#C7C4B6", backgroundColor: "#F8F7F2" }}>
            {!photo ? (
              <div className="flex gap-2 justify-center flex-wrap">
                <label className="inline-flex items-center gap-2 px-4 py-2.5 rounded-sm text-sm font-semibold cursor-pointer" style={{ backgroundColor: "#202B26", color: "#F8F7F2" }}>
                  <Camera size={16} /> Take photo
                  <input type="file" accept="image/*" capture="environment" onChange={handleFile} className="hidden" />
                </label>
                <label className="inline-flex items-center gap-2 px-4 py-2.5 rounded-sm text-sm font-semibold cursor-pointer border" style={{ borderColor: "#202B26", color: "#202B26" }}>
                  <Upload size={16} /> Choose from library
                  <input ref={fileInputRef} type="file" accept="image/*" onChange={handleFile} className="hidden" />
                </label>
              </div>
            ) : (
              <div className="space-y-3">
                <img src={photo} alt="Selected" className="max-h-56 mx-auto rounded-sm border" style={{ borderColor: "#D8D6CB" }} />
                <input
                  type="text"
                  value={context}
                  onChange={(e) => setContext(e.target.value)}
                  placeholder="Optional: room / element"
                  className="w-full px-3 py-2 rounded-sm border text-sm"
                  style={{ borderColor: "#D8D6CB" }}
                />
                <div className="flex gap-2 justify-center">
                  <button onClick={resetCapture} className="px-3 py-2 rounded-sm text-sm flex items-center gap-1.5" style={{ color: "#8A8575" }}>
                    <RotateCcw size={14} /> Retake
                  </button>
                  <button
                    onClick={submitPhoto}
                    disabled={submitting}
                    className="px-4 py-2 rounded-sm text-sm font-semibold"
                    style={{ backgroundColor: "#E8A33D", color: "#202B26" }}
                  >
                    {submitting ? "Saving…" : online ? "Run triage" : "Save offline"}
                  </button>
                </div>
              </div>
            )}
            {error && <p className="text-xs mt-3" style={{ color: "#B23A2A" }}>{error}</p>}
          </div>
        )}

        {/* Report download */}
        {siteId && online && (
          <button onClick={downloadReport} className="flex items-center gap-1.5 text-sm font-medium" style={{ color: "#3E5C6E" }}>
            <FileDown size={15} /> Download site report (PDF)
          </button>
        )}

        {/* Log */}
        <div className="space-y-3">
          {queue.filter((q) => q.siteId === siteId).map((q) => (
            <div key={q.id} className="rounded-md p-3 border" style={{ backgroundColor: "#F8F7F2", borderColor: "#D8D6CB" }}>
              <p className="text-xs font-semibold" style={{ color: "#B8791F" }}>QUEUED — not yet analysed</p>
              <p className="text-xs mt-1" style={{ color: "#8A8575" }}>{q.context || "No context noted"}</p>
            </div>
          ))}
          {serverLog.map((d) => {
            const style = CATEGORY_STYLE[d.category] || CATEGORY_STYLE.review;
            return (
              <div key={d.id} className="rounded-md p-3 border flex gap-3" style={{ backgroundColor: "#F8F7F2", borderColor: "#D8D6CB" }}>
                {d.photo_signed_url && (
                  <img src={d.photo_signed_url} alt="" className="w-16 h-16 object-cover rounded-sm flex-shrink-0" />
                )}
                <div className="min-w-0">
                  <span className="text-xs font-bold" style={{ color: style.color }}>{style.label}</span>
                  <p className="text-sm mt-0.5" style={{ color: "#3A362E" }}>
                    <span className="font-semibold">{d.trade}. </span>{d.description}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </main>
    </div>
  );
}
