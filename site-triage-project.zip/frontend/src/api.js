const API_BASE = import.meta.env.VITE_API_BASE_URL || "http://localhost:4000";

async function request(path, { method = "GET", token, body, isForm = false } = {}) {
  const headers = {};
  if (token) headers.Authorization = `Bearer ${token}`;
  if (!isForm && body) headers["Content-Type"] = "application/json";

  const res = await fetch(`${API_BASE}${path}`, {
    method,
    headers,
    body: isForm ? body : body ? JSON.stringify(body) : undefined,
  });

  if (!res.ok) {
    let message = `Request failed (${res.status})`;
    try {
      const data = await res.json();
      if (data.error) message = data.error;
    } catch (_) {}
    throw new Error(message);
  }
  return res.json();
}

export function login(email, password) {
  return request("/api/auth/login", { method: "POST", body: { email, password } });
}

export function getSites(token) {
  return request("/api/sites", { token });
}

export function createSite(token, site) {
  return request("/api/sites", { method: "POST", token, body: site });
}

export function getDefects(token, siteId) {
  return request(`/api/defects?site_id=${siteId}`, { token });
}

export function getTopics(token) {
  return request("/api/topics", { token });
}

/**
 * Uploads a photo for triage. photoBlob must be a Blob/File.
 * Throws if offline or the request fails — caller decides whether to queue.
 */
export async function uploadDefect(token, { siteId, context, photoBlob }) {
  const form = new FormData();
  form.append("site_id", siteId);
  if (context) form.append("context", context);
  form.append("photo", photoBlob, "photo.jpg");

  return request("/api/defects", { method: "POST", token, body: form, isForm: true });
}

/**
 * Downloads the PDF report for a site as a blob (auth headers can't be
 * attached to a plain link, so we fetch and hand back an object URL).
 */
export async function downloadSiteReport(token, siteId) {
  const res = await fetch(`${API_BASE}/api/reports/site/${siteId}`, {
    headers: { Authorization: `Bearer ${token}` },
  });
  if (!res.ok) throw new Error("Report download failed");
  const blob = await res.blob();
  return URL.createObjectURL(blob);
}

export { API_BASE };
