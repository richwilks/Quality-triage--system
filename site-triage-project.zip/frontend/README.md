# Site Triage — Frontend

React app for the site: sign in, pick a site, take/upload photos, and see
triage results. Works offline — photos taken with no signal are saved on
the phone and automatically sent for AI analysis once you're back online.

## For Richard: how to actually get this running

You don't need to write any code yourself. The plan is to use **Claude
Code** (Anthropic's coding tool — different from the claude.ai chat app)
to do the technical steps, with you following along and making the
account/product decisions.

### Step 1 — Install Claude Code

Go to `https://docs.claude.com` and search "Claude Code" for the current
install instructions (this changes over time, so check there rather than
relying on anything written here). It runs from a terminal on your
computer (Mac, Windows, or Linux).

### Step 2 — Give Claude Code this project

Put the `backend` and `frontend` folders somewhere on your computer (e.g.
a folder called `site-triage`), open a terminal in that folder, and start
Claude Code there. Then just talk to it in plain English — it can read
these folders itself.

### Step 3 — Suggested first prompts to Claude Code

Do these roughly in order, one at a time, checking each works before
moving to the next:

1. *"Read through the backend and frontend folders and give me a summary
   of what this project does and what's needed to run it."*
2. *"Help me create a free Supabase account and a new project, and get me
   the database connection string and storage credentials I need for the
   backend's .env file."*
3. *"Help me set up the .env files for both backend and frontend using
   what we just got from Supabase, plus my Anthropic API key."*
   (Get your API key from `console.anthropic.com` — a different login
   from your claude.ai account.)
4. *"Run the database migration and start the backend locally, and help
   me fix anything that breaks."*
5. *"Create my first admin user in the database."*
6. *"Start the frontend and let's test logging in and uploading a
   photo."*
7. *"Now let's test offline mode — help me simulate no connection in the
   browser and confirm photos get queued and then sync properly."*

Claude Code will ask you to confirm things and may hit errors — that's
normal. Paste the error back to it and let it fix it.

### Step 4 — Try it for real

Once it runs locally, take it on-site on your laptop or phone (same
Wi-Fi network as your computer, or deployed properly — ask Claude Code
about deploying to Render/Vercel once you're happy with it locally).

### Step 5 — When the concept is proven

Hand the whole project (plus notes on what worked/didn't on real sites)
to a freelance developer to harden it: proper hosting, a nicer login
flow, better error handling, and a fuller standards reference library.

## What "offline" actually does here

- Taking a photo with no signal saves it on your device (in the
  browser's local storage), tagged "queued".
- As soon as the app detects a connection again, it automatically sends
  every queued photo to the backend for AI triage.
- You can also tap "Sync now" to force a check.
- Nothing is lost if you close the app while offline — the queue
  persists until it successfully syncs.

## Local run (once .env files are set up)

```bash
# backend
cd backend && npm install && npm run migrate && npm run dev

# frontend, in a second terminal
cd frontend && npm install && npm run dev
```

Then open the URL the frontend prints (usually `http://localhost:5173`).
