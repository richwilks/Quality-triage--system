const express = require("express");
const { pool } = require("../db");
const { requireAuth } = require("../middleware/auth");

const router = express.Router();

// GET /api/sites — list all sites
router.get("/", requireAuth, async (req, res) => {
  const { rows } = await pool.query(
    `select s.*, count(d.id) filter (where d.status != 'closed') as open_defect_count
     from sites s
     left join defects d on d.site_id = s.id
     group by s.id
     order by s.created_at desc`
  );
  res.json({ sites: rows });
});

// POST /api/sites — create a new site
router.post("/", requireAuth, async (req, res) => {
  const { name, address, client_name } = req.body;
  if (!name) return res.status(400).json({ error: "Site name is required" });

  const { rows } = await pool.query(
    `insert into sites (name, address, client_name, created_by)
     values ($1, $2, $3, $4)
     returning *`,
    [name, address || null, client_name || null, req.user.id]
  );
  res.status(201).json({ site: rows[0] });
});

// GET /api/sites/:id — single site detail
router.get("/:id", requireAuth, async (req, res) => {
  const { rows } = await pool.query("select * from sites where id = $1", [req.params.id]);
  if (rows.length === 0) return res.status(404).json({ error: "Site not found" });
  res.json({ site: rows[0] });
});

module.exports = router;
