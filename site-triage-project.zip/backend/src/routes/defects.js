const express = require("express");
const multer = require("multer");
const { pool } = require("../db");
const { requireAuth } = require("../middleware/auth");
const { uploadPhoto, getSignedPhotoUrl } = require("../services/storage");
const { runTriage } = require("../services/triage");

const router = express.Router();
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 15 * 1024 * 1024 }, // 15MB
});

// POST /api/defects — upload a photo, run triage, save the record
// multipart/form-data fields: photo (file), site_id, context (optional)
router.post("/", requireAuth, upload.single("photo"), async (req, res) => {
  try {
    const { site_id, context } = req.body;
    if (!site_id) return res.status(400).json({ error: "site_id is required" });
    if (!req.file) return res.status(400).json({ error: "photo file is required" });

    const base64 = req.file.buffer.toString("base64");
    const mediaType = req.file.mimetype;

    const [photoKey, result] = await Promise.all([
      uploadPhoto(req.file.buffer, mediaType),
      runTriage({ base64, mediaType, context }),
    ]);

    const { rows } = await pool.query(
      `insert into defects
        (site_id, inspector_id, photo_url, location_context, category, severity,
         trade, description, topic_ids, confidence, note, status)
       values ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,'open')
       returning *`,
      [
        site_id,
        req.user.id,
        photoKey,
        context || null,
        result.category,
        result.severity,
        result.trade,
        result.description,
        JSON.stringify(result.topic_ids),
        result.confidence,
        result.note,
      ]
    );

    const defect = rows[0];
    defect.photo_signed_url = await getSignedPhotoUrl(defect.photo_url);
    res.status(201).json({ defect });
  } catch (err) {
    console.error("Defect creation failed:", err);
    res.status(500).json({ error: "Triage or save failed. Try again." });
  }
});

// GET /api/defects?site_id=... — list defects, optionally filtered
router.get("/", requireAuth, async (req, res) => {
  const { site_id, status, category } = req.query;
  const conditions = [];
  const params = [];

  if (site_id) {
    params.push(site_id);
    conditions.push(`site_id = $${params.length}`);
  }
  if (status) {
    params.push(status);
    conditions.push(`status = $${params.length}`);
  }
  if (category) {
    params.push(category);
    conditions.push(`category = $${params.length}`);
  }

  const whereClause = conditions.length ? `where ${conditions.join(" and ")}` : "";
  const { rows } = await pool.query(
    `select * from defects ${whereClause} order by created_at desc`,
    params
  );

  const defects = await Promise.all(
    rows.map(async (d) => ({ ...d, photo_signed_url: await getSignedPhotoUrl(d.photo_url) }))
  );

  res.json({ defects });
});

// GET /api/defects/:id
router.get("/:id", requireAuth, async (req, res) => {
  const { rows } = await pool.query("select * from defects where id = $1", [req.params.id]);
  if (rows.length === 0) return res.status(404).json({ error: "Defect not found" });

  const defect = rows[0];
  defect.photo_signed_url = await getSignedPhotoUrl(defect.photo_url);
  res.json({ defect });
});

// PATCH /api/defects/:id — inspector confirms/edits category, severity, or status
router.patch("/:id", requireAuth, async (req, res) => {
  const { category, severity, status, description } = req.body;
  const fields = [];
  const params = [];

  const addField = (name, value) => {
    params.push(value);
    fields.push(`${name} = $${params.length}`);
  };

  if (category) addField("category", category);
  if (severity) addField("severity", severity);
  if (status) addField("status", status);
  if (description) addField("description", description);
  fields.push(`updated_at = now()`);

  if (fields.length === 1) {
    return res.status(400).json({ error: "No updatable fields provided" });
  }

  params.push(req.params.id);
  const { rows } = await pool.query(
    `update defects set ${fields.join(", ")} where id = $${params.length} returning *`,
    params
  );

  if (rows.length === 0) return res.status(404).json({ error: "Defect not found" });
  res.json({ defect: rows[0] });
});

module.exports = router;
