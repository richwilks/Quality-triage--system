const express = require("express");
const { pool } = require("../db");
const { requireAuth, requireAdmin } = require("../middleware/auth");

const router = express.Router();

// GET /api/topics — list all active topics (any logged-in user)
router.get("/", requireAuth, async (req, res) => {
  const { rows } = await pool.query(
    "select * from standards_topics where active = true order by source, id"
  );
  res.json({ topics: rows });
});

// POST /api/topics — add a new reference topic (admin only)
// This is how you grow the reference list with your own QM knowledge over time.
router.post("/", requireAuth, requireAdmin, async (req, res) => {
  const { id, source, area } = req.body;
  if (!id || !source || !area) {
    return res.status(400).json({ error: "id, source, and area are all required" });
  }

  const { rows } = await pool.query(
    `insert into standards_topics (id, source, area)
     values ($1, $2, $3)
     on conflict (id) do update set source = excluded.source, area = excluded.area, active = true
     returning *`,
    [id, source, area]
  );
  res.status(201).json({ topic: rows[0] });
});

// PATCH /api/topics/:id/deactivate — soft-remove a topic without breaking old records
router.patch("/:id/deactivate", requireAuth, requireAdmin, async (req, res) => {
  const { rows } = await pool.query(
    "update standards_topics set active = false where id = $1 returning *",
    [req.params.id]
  );
  if (rows.length === 0) return res.status(404).json({ error: "Topic not found" });
  res.json({ topic: rows[0] });
});

module.exports = router;
