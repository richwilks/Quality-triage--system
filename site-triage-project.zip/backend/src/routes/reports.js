const express = require("express");
const { pool } = require("../db");
const { requireAuth } = require("../middleware/auth");
const { generateSiteReport } = require("../services/pdf");

const router = express.Router();

// GET /api/reports/site/:siteId — streams a PDF report of all defects for a site
router.get("/site/:siteId", requireAuth, async (req, res) => {
  const { siteId } = req.params;

  const siteResult = await pool.query("select * from sites where id = $1", [siteId]);
  if (siteResult.rows.length === 0) {
    return res.status(404).json({ error: "Site not found" });
  }
  const site = siteResult.rows[0];

  const defectsResult = await pool.query(
    "select * from defects where site_id = $1 order by created_at asc",
    [siteId]
  );

  const topicsResult = await pool.query("select * from standards_topics");
  const topicsById = Object.fromEntries(topicsResult.rows.map((t) => [t.id, t]));

  res.setHeader("Content-Type", "application/pdf");
  res.setHeader("Content-Disposition", `attachment; filename="${site.name.replace(/[^a-z0-9]/gi, "_")}_report.pdf"`);

  try {
    await generateSiteReport({ site, defects: defectsResult.rows, topicsById }, res);
  } catch (err) {
    console.error("Report generation failed:", err);
    if (!res.headersSent) res.status(500).json({ error: "Report generation failed" });
  }
});

module.exports = router;
