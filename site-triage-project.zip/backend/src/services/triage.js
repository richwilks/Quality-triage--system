const { pool } = require("../db");

const ANTHROPIC_URL = "https://api.anthropic.com/v1/messages";

function buildSystemPrompt(topics) {
  const topicListText = topics
    .map((t) => `${t.id} :: ${t.source} — ${t.area}`)
    .join("\n");

  return `You are a triage assistant helping a UK construction quality manager sort site inspection photos during snagging and handover.

Classify the photo into exactly one category: "snag" (cosmetic/finishing, no functional or compliance impact), "defect" (workmanship/material below required standard, remedial work needed), or "ncr" (a formal breach of a specified requirement — especially anything safety-critical such as fire, structural, or electrical). If you cannot tell from the photo alone, use "review".

Rate severity as one of: cosmetic, minor, major, critical.

From the topic list below, select up to 3 ids that best match what the photo shows. You MUST only use ids from this list — never invent a clause, chapter, or standard number that is not in the list. If nothing fits well, use COSMETIC or omit.

Topic list:
${topicListText}

Respond with ONLY raw JSON, no markdown fences, no preamble, in exactly this shape:
{"category":"snag|defect|ncr|review","severity":"cosmetic|minor|major|critical","trade":"short trade name e.g. Electrical, Render, Joinery","description":"2 sentences describing what you observe, plain language","topic_ids":["ID1","ID2"],"confidence":"low|medium|high","note":"one sentence on why, and what a human inspector should verify"}`;
}

/**
 * Runs AI triage on a photo. Pulls the active topic list from the database
 * so the reference list can be maintained without redeploying code.
 */
async function runTriage({ base64, mediaType, context }) {
  const { rows: topics } = await pool.query(
    "select id, source, area from standards_topics where active = true order by id"
  );

  const systemPrompt = buildSystemPrompt(topics);
  const userText = context
    ? `Location/context supplied by inspector: ${context}`
    : "No additional context supplied by inspector.";

  const response = await fetch(ANTHROPIC_URL, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": process.env.ANTHROPIC_API_KEY,
      "anthropic-version": "2023-06-01",
    },
    body: JSON.stringify({
      model: "claude-sonnet-4-6",
      max_tokens: 1000,
      system: systemPrompt,
      messages: [
        {
          role: "user",
          content: [
            { type: "image", source: { type: "base64", media_type: mediaType, data: base64 } },
            { type: "text", text: userText },
          ],
        },
      ],
    }),
  });

  if (!response.ok) {
    const errText = await response.text();
    throw new Error(`Anthropic API error (${response.status}): ${errText}`);
  }

  const data = await response.json();
  const textBlock = (data.content || []).find((b) => b.type === "text");
  if (!textBlock) throw new Error("No text response from model");

  const cleaned = textBlock.text.replace(/```json|```/g, "").trim();
  const parsed = JSON.parse(cleaned);

  // Defensive validation — never trust model output blindly for enum fields.
  const validCategories = ["snag", "defect", "ncr", "review"];
  const validSeverities = ["cosmetic", "minor", "major", "critical"];
  if (!validCategories.includes(parsed.category)) parsed.category = "review";
  if (!validSeverities.includes(parsed.severity)) parsed.severity = "major";
  if (!Array.isArray(parsed.topic_ids)) parsed.topic_ids = [];

  const validIds = new Set(topics.map((t) => t.id));
  parsed.topic_ids = parsed.topic_ids.filter((id) => validIds.has(id));

  return parsed;
}

module.exports = { runTriage };
