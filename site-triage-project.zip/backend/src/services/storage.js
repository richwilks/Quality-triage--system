const { S3Client, PutObjectCommand, GetObjectCommand } = require("@aws-sdk/client-s3");
const { getSignedUrl } = require("@aws-sdk/s3-request-presigner");
const { v4: uuidv4 } = require("uuid");

const s3 = new S3Client({
  endpoint: process.env.S3_ENDPOINT,
  region: process.env.S3_REGION || "auto",
  credentials: {
    accessKeyId: process.env.S3_ACCESS_KEY_ID,
    secretAccessKey: process.env.S3_SECRET_ACCESS_KEY,
  },
  forcePathStyle: true,
});

const BUCKET = process.env.S3_BUCKET;

/**
 * Uploads a photo buffer to object storage and returns the storage key.
 * Store the key (not a public URL) in the database — generate signed
 * URLs on read so photos aren't publicly accessible without auth.
 */
async function uploadPhoto(buffer, mimeType) {
  const ext = (mimeType || "image/jpeg").split("/")[1] || "jpg";
  const key = `defects/${new Date().toISOString().slice(0, 10)}/${uuidv4()}.${ext}`;

  await s3.send(
    new PutObjectCommand({
      Bucket: BUCKET,
      Key: key,
      Body: buffer,
      ContentType: mimeType,
    })
  );

  return key;
}

/**
 * Generates a short-lived signed URL for viewing a stored photo.
 */
async function getSignedPhotoUrl(key, expiresInSeconds = 3600) {
  const command = new GetObjectCommand({ Bucket: BUCKET, Key: key });
  return getSignedUrl(s3, command, { expiresIn: expiresInSeconds });
}

/**
 * Fetches the raw bytes of a stored photo — used when embedding images
 * directly into generated PDF reports (pdfkit needs bytes, not a URL).
 */
async function getPhotoBuffer(key) {
  const command = new GetObjectCommand({ Bucket: BUCKET, Key: key });
  const response = await s3.send(command);
  const chunks = [];
  for await (const chunk of response.Body) {
    chunks.push(chunk);
  }
  return Buffer.concat(chunks);
}

module.exports = { uploadPhoto, getSignedPhotoUrl, getPhotoBuffer };
