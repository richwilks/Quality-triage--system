const PDFDocument = require("pdfkit");
const { getPhotoBuffer } = require("./storage");

const CATEGORY_LABEL = { snag: "SNAG", defect: "DEFECT", ncr: "NCR", review: "NEEDS REVIEW" };

/**
 * Streams a PDF site report directly to the given writable stream (e.g. an
 * HTTP response). Includes one section per defect with photo, classification,
 * severity, and matched reference topics.
 */
async function generateSiteReport({ site, defects, topicsById }, outStream) {
  const doc = new PDFDocument({ margin: 50, size: "A4" });
  doc.pipe(outStream);

  doc
    .fontSize(20)
    .text(site.name, { continued: false })
    .fontSize(10)
    .fillColor("#555555")
    .text(site.address || "")
    .text(site.client_name ? `Client: ${site.client_name}` : "")
    .moveDown(0.5)
    .text(`Report generated: ${new Date().toLocaleString("en-GB")}`)
    .text(`Total items: ${defects.length}`)
    .moveDown(1);

  doc.fillColor("#000000");

  for (const [index, d] of defects.entries()) {
    if (doc.y > 620) doc.addPage();

    doc
      .moveDown(0.5)
      .fontSize(13)
      .fillColor("#000000")
      .text(`${index + 1}. ${CATEGORY_LABEL[d.category] || d.category.toUpperCase()} — ${d.trade || "Unspecified trade"}`, {
        underline: true,
      })
      .fontSize(9)
      .fillColor("#666666")
      .text(`Severity: ${d.severity.toUpperCase()}    Status: ${d.status.toUpperCase()}    Logged: ${new Date(d.created_at).toLocaleDateString("en-GB")}`)
      .moveDown(0.3);

    try {
      const imageBuffer = await getPhotoBuffer(d.photo_url);
      doc.image(imageBuffer, { fit: [180, 180], align: "left" });
      doc.moveDown(0.5);
    } catch (err) {
      doc.fontSize(9).fillColor("#aa0000").text("[Photo unavailable]").moveDown(0.3);
    }

    doc.fontSize(10).fillColor("#000000").text(d.description || "No description recorded.");

    const topicIds = Array.isArray(d.topic_ids) ? d.topic_ids : JSON.parse(d.topic_ids || "[]");
    if (topicIds.length > 0) {
      doc.moveDown(0.2).fontSize(9).fillColor("#333333").text("Suggested reference topics:", { continued: false });
      for (const id of topicIds) {
        const topic = topicsById[id];
        if (topic) {
          doc.text(`  • ${topic.id} — ${topic.source}: ${topic.area}`);
        }
      }
      doc
        .fontSize(8)
        .fillColor("#888888")
        .text("AI-suggested topic areas only — verify against the current published standard before treating as a formal finding.");
    }

    if (d.location_context) {
      doc.fontSize(9).fillColor("#333333").text(`Location: ${d.location_context}`);
    }

    doc.moveDown(1);
    doc.fillColor("#000000");
  }

  doc.end();
}

module.exports = { generateSiteReport };
