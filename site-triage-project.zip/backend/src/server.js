require("dotenv").config();
const express = require("express");
const cors = require("cors");

const authRoutes = require("./routes/auth");
const siteRoutes = require("./routes/sites");
const defectRoutes = require("./routes/defects");
const topicRoutes = require("./routes/topics");
const reportRoutes = require("./routes/reports");

const app = express();

const allowedOrigins = (process.env.ALLOWED_ORIGINS || "").split(",").map((s) => s.trim()).filter(Boolean);
app.use(
  cors({
    origin: allowedOrigins.length ? allowedOrigins : true,
  })
);
app.use(express.json({ limit: "2mb" }));

app.get("/health", (req, res) => res.json({ ok: true }));

app.use("/api/auth", authRoutes);
app.use("/api/sites", siteRoutes);
app.use("/api/defects", defectRoutes);
app.use("/api/topics", topicRoutes);
app.use("/api/reports", reportRoutes);

// Fallback error handler — keeps stack traces out of API responses
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: "Unexpected server error" });
});

const port = process.env.PORT || 4000;
app.listen(port, () => {
  console.log(`Site triage backend listening on port ${port}`);
});
