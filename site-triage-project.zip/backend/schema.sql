-- Site Triage backend schema (Postgres)
-- Run this once against a fresh database before starting the server.

create extension if not exists "pgcrypto";

create table if not exists users (
  id uuid primary key default gen_random_uuid(),
  email text unique not null,
  password_hash text not null,
  name text not null,
  role text not null default 'inspector' check (role in ('admin', 'inspector')),
  created_at timestamptz not null default now()
);

create table if not exists sites (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  address text,
  client_name text,
  created_by uuid references users(id),
  created_at timestamptz not null default now()
);

create table if not exists standards_topics (
  id text primary key,           -- e.g. 'NHBC-EXT-RENDER'
  source text not null,          -- e.g. 'NHBC Standards'
  area text not null,            -- e.g. 'External wall finishes & render'
  active boolean not null default true
);

create table if not exists defects (
  id uuid primary key default gen_random_uuid(),
  site_id uuid not null references sites(id) on delete cascade,
  inspector_id uuid references users(id),
  photo_url text not null,
  location_context text,
  category text not null check (category in ('snag', 'defect', 'ncr', 'review')),
  severity text not null check (severity in ('cosmetic', 'minor', 'major', 'critical')),
  trade text,
  description text,
  topic_ids jsonb not null default '[]',
  confidence text check (confidence in ('low', 'medium', 'high')),
  note text,
  status text not null default 'open' check (status in ('open', 'in_progress', 'closed', 'verified')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists idx_defects_site on defects(site_id);
create index if not exists idx_defects_status on defects(status);

-- Seed starter topic list — expand this over time with your own QM knowledge.
insert into standards_topics (id, source, area) values
  ('NHBC-EXT-RENDER', 'NHBC Standards', 'External wall finishes & render'),
  ('NHBC-INT-FINISH', 'NHBC Standards', 'Internal finishes, joinery & decoration'),
  ('NHBC-STRUCT', 'NHBC Standards', 'Structural elements, movement & cracking'),
  ('NHBC-ROOF', 'NHBC Standards', 'Roofing & weatherproofing'),
  ('NHBC-FIRE', 'NHBC Standards', 'Fire stopping & compartmentation'),
  ('ADB-FIRE', 'Approved Document B', 'Fire safety'),
  ('ADC-DAMP', 'Approved Document C', 'Site preparation & resistance to moisture'),
  ('ADE-SOUND', 'Approved Document E', 'Resistance to sound'),
  ('ADL-ENERGY', 'Approved Document L', 'Conservation of fuel & power'),
  ('ADM-ACCESS', 'Approved Document M', 'Access to and use of buildings'),
  ('ADP-ELEC', 'Approved Document P', 'Electrical safety in dwellings'),
  ('BS7671-PROT', 'BS 7671', 'Protection against electric shock'),
  ('BS7671-INSTALL', 'BS 7671', 'Selection & erection of wiring systems'),
  ('BS7671-TEST', 'BS 7671', 'Inspection, testing & certification'),
  ('BSA-GT', 'Building Safety Act 2022', 'Golden Thread / higher-risk building info duties'),
  ('REG38', 'Building Regs Reg 38', 'Fire safety information at handover'),
  ('COSMETIC', '—', 'Cosmetic/finish tolerance only, no standard breach identified')
on conflict (id) do nothing;
