# Site Triage — Backend

Backend API for the AI-assisted snag / defect / NCR site triage app.
Handles auth, sites, photo upload + AI triage, and PDF report export.

## Stack

- **Node.js + Express** — API server
- **Postgres** — sites, defects, users, standards-topic reference list
- **S3-compatible object storage** — photo files (works with AWS S3, Cloudflare R2, or Supabase Storage)
- **Claude API** (server-side key) — photo triage
- **pdfkit** — client-ready PDF report export

## 1. Get accounts set up

You'll need, at minimum:

1. A Postgres database — easiest options for a solo build:
   - [Supabase](https://supabase.com) (free tier, gives you Postgres + storage + auth in one place)
   - [Railway](https://railway.app) or [Render](https://render.com) (simple managed Postgres)
2. An S3-compatible storage bucket — Supabase Storage, Cloudflare R2, or AWS S3 all work.
3. Your own Anthropic API key from [console.anthropic.com](https://console.anthropic.com) — this is separate from your claude.ai login.
4. A place to host the Node server — Render, Railway, or Fly.io are the simplest for a first deployment.

## 2. Local setup

```bash
cd backend
npm install
cp .env.example .env
# edit .env with your real DATABASE_URL, JWT_SECRET, ANTHROPIC_API_KEY, and S3 credentials
npm run migrate   # creates tables and seeds the starter standards-topic list
npm run dev       # starts the server on http://localhost:4000
```

Check it's alive:

```bash
curl http://localhost:4000/health
```

## 3. Create your first user

There's no public sign-up route by design — the first account has to be inserted directly, then that account can create others via `/api/auth/register`.

```sql
-- Run this once against your database, with a real bcrypt hash.
-- Generate a hash locally with: node -e "console.log(require('bcryptjs').hashSync('yourpassword', 12))"
insert into users (email, password_hash, name, role)
values ('you@example.com', '$2a$12$...your-hash-here...', 'Richard', 'admin');
```

Then log in:

```bash
curl -X POST http://localhost:4000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"you@example.com","password":"yourpassword"}'
```

Use the returned `token` as `Authorization: Bearer <token>` on every other request.

## 4. API overview

| Method | Path | Purpose |
|---|---|---|
| POST | `/api/auth/login` | Log in, get a token |
| POST | `/api/auth/register` | Admin creates a new user |
| GET | `/api/sites` | List sites with open defect counts |
| POST | `/api/sites` | Create a site |
| GET | `/api/defects?site_id=...` | List defects, filterable by status/category |
| POST | `/api/defects` | Upload a photo (`multipart/form-data`, field `photo`), runs AI triage, saves the record |
| PATCH | `/api/defects/:id` | Confirm/edit category, severity, status |
| GET | `/api/topics` | List the standards reference topics |
| POST | `/api/topics` | Add/update a reference topic (admin) |
| GET | `/api/reports/site/:siteId` | Streams a PDF report for the site |

Example upload:

```bash
curl -X POST http://localhost:4000/api/defects \
  -H "Authorization: Bearer <token>" \
  -F "site_id=<site-uuid>" \
  -F "context=Kitchen, socket by window" \
  -F "photo=@/path/to/photo.jpg"
```

## 5. Growing the standards reference list

The `standards_topics` table is deliberately small to start and deliberately paraphrased rather than verbatim, to avoid reproducing copyrighted standard text. Add to it via `POST /api/topics` as you validate real coverage against your own QM knowledge — this list is the part of the system most worth your ongoing attention, more than the code itself.

## 6. Known gaps to close before real site use

- **Offline queueing** — the current frontend prototype assumes live connectivity. Poor site signal will need photos queued locally and synced later; this is a frontend change, not a backend one.
- **Rate limiting** — no throttling is in place yet on triage or auth endpoints.
- **Audit trail** — `updated_at` is tracked, but there's no history of who changed what and when. Worth adding if this ever needs to stand up to a dispute.
- **Multi-tenancy** — as built, all users see all sites. If you ever run this for more than one client organisation, you'll need to scope sites to an organisation/tenant.
